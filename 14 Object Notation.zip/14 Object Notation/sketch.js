// Object Notation
// Jeffrey Hamilton
// 28/Mar/2024

let ballArray = [];
let showBallText = true;
let chaosMode = false;
let ballDecayMode = false;

function setup() {
  createCanvas(windowWidth, windowHeight);
  noStroke();
  strokeWeight(1);
  textAlign(CENTER);
  textSize(15);
}

function mousePressed() {
  spawnBall(mouseX,mouseY);
}

function spawnBall(initialX,initialY) {
  let ball = {
    x: initialX,
    y: initialY,
    radius: 30,
    xSpeed: random(-5,5),
    ySpeed: random(-5,5),
    colour: [random(0,255),random(0,255),random(0,255)],
    bounces: 0,
    ballLife: round(random(1,10)), // Number of bounces the ball will reach before being discarded.
    cooldown: 100, // Number of frames before ball can duplicate on contact with a wall in Chaos Mode.
  };
  ballArray.push(ball);
}

function collisions(j) { // NOT WORKING (Yet)
  let bCurr = ballArray[j];
  let radius = bCurr.radius;
  for(i=0; i<ballArray.length; i++) {
    if(i!=j) {
      let b = ballArray[i];
      let xBounds = (bCurr.x-(radius/2) <= b.x+(radius/2) && bCurr.x+(radius/2) >= b.x-(radius/2));
      let yBounds = (bCurr.y-(radius/2) <= b.y+(radius/2) && bCurr.y+(radius/2) >= b.y-(radius/2)); 
      if(xBounds&&yBounds) {
        bCurr.xSpeed *= -1;
        b.xSpeed *= -1;
        bCurr.ySpeed *= -1;
        b.ySpeed *= -1;
      }
    }
  }
}



function draw() {
  background(220);
  for(let i=0; i<ballArray.length; i++) {
    let b=ballArray[i];

    if(b.x < 0 || b.x > width) {
      b.xSpeed *= -1; // Inverts speed to switch direction.
      b.bounces++; // Increases bounce variable to keep track of when the ball should be discarded.

      if(chaosMode&&b.cooldown===0) { // You can see where this is going...
        b.cooldown = 100;
        spawnBall(b.x+b.xSpeed,b.y);
      }
    }
    if(b.y < 0 || b.y > height) {
      b.ySpeed *= -1; // Inverts speed to switch direction.
      b.bounces++; // Increases bounce variable to keep track of when the ball should be discarded.

      if(chaosMode&&b.cooldown===0) { // You can see where this is going...
        b.cooldown = 100;
        spawnBall(b.x,b.y+b.ySpeed);
      }
    }

    collisions(i);

    if(chaosMode&&b.cooldown>0) {
      b.cooldown--;
    }

    if((b.bounces>=b.ballLife)&&ballDecayMode===true) {
      ballArray.splice(i,1); // Removes the current ball.
      i--; // Next ball in ballArray becomes current i value, so i-- to repeat the current i to not skip next ball.
    } else {
      fill(b.colour);
      noStroke();
      circle(b.x,b.y,b.radius);

      if(showBallText) { // Displays bounces on ball if showBallText is true.
        stroke(0);
        fill(255);
        if(chaosMode) {
          text(b.cooldown,b.x,b.y+5); // Draws the cooldown used for Chaos Mode on the ball.
        } else if(ballDecayMode===true) {
          text((b.bounces + "/" + b.ballLife),b.x,b.y+5); // Draws the bounces/ballLife on the ball.
        } else {
          text(b.bounces,b.x,b.y+5)
        }
      }

      b.x+=b.xSpeed;
      b.y+=b.ySpeed;
    }
  }
}
